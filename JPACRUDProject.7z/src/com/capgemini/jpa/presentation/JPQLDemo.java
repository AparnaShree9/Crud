package com.capgemini.jpa.presentation;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;

public class JPQLDemo {
	
	public static void main(String[] args) {
		
				/*EntityManager entityManager = JPAUtil.getEntityManager();
		
		String jql1 ="select e from Employee e";
	TypedQuery<Employee>typedQuery1 = entityManager.createQuery(jql1,Employee.class);
	List<Employee> employeeList = typedQuery1.getResultList();
	showEmployees(employeeList);
	}

	
		}*/
	EntityManager entityManager = JPAUtil.getEntityManager();
	String jql1 ="select e from Employee e WHERE e.job=:ptitle";
	TypedQuery<Employee>query=entityManager.createQuery(jql1,Employee.class);
	/*query.setParameter("ptitle","Tester" );
	Employee e =query.getSingleResult();
	System.out.println(e);*/
	query.setParameter("ptitle","Developer" );
	List<Employee> employeeList = query.getResultList();
	showEmployees(employeeList);
}
	private static void showEmployees(List<Employee> employeeList) {
		Iterator<Employee>iterator=employeeList.iterator();
		while(iterator.hasNext()){
		System.out.println(iterator.next());
	}
}
	}