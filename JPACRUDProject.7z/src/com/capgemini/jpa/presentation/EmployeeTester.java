package com.capgemini.jpa.presentation;

import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.service.EmployeeServiceImpl;
import com.capgemini.jpa.service.IEmployeeService;

public class EmployeeTester {
	private static IEmployeeService employeeService=
								new EmployeeServiceImpl();
	private static Employee emp = new Employee();
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
		System.out.println("Choose the function you want to perform");
		System.out.println("1. Add new Employee");
		System.out.println("2. Delete an Employee");
		System.out.println("3. Update the details of an Employee");
		System.out.println("4. Get the details of an Employee");
		System.out.println("5. Get the details of all Employee");
		System.out.println("6. Exit");
		int n = sc.nextInt();
		switch (n) {
		case 1:
			Employee employee=
		    new Employee(null,"shayam",new GregorianCalendar(2012,8,23),"Developer",70000.0,10);
		
		    addNewEmployee(employee);
			break;
			
			
        case 2:
			System.out.println("Enter the employee id  :");
			int q = sc.nextInt();
			deleteEmployee(q);
			break;
			
        case 3:
	       // System.out.println("Update the details");
	        System.out.println("Update the details of the employee ID  :");
			int r = sc.nextInt();
         try{
	        Employee employee1 =getEmployeeDetails(r);
	        //System.out.println(employee1);
	        employee1.setSalary(68000.0);
	           
	       employeeService.updateEmployee(employee1);
	       Employee employee2 =getEmployeeDetails(r);
	       System.out.println(employee2);
         } catch (EmployeeException e) {			
 			e.printStackTrace();
 		}
	        break;
	       
        case 4:
	      System.out.println("Enter the empid of the Employee to get the details");
	      int w = sc.nextInt();
	     Employee emp = getEmployeeDetails(w);
	     System.out.println(emp);
	        break;
	        
	        
        case 5:
        		System.out.println("The employee details are  :");
        		try{
        		List<Employee>empL = employeeService.getAllEmployees();
        		
        		showEmployees(empL);
        		} catch (EmployeeException e) {			
        			e.printStackTrace();
        		}
	        break;
        case 6:
        	System.out.print("Exit Employee details system");
			System.exit(0);	
	        break;
		default:
			System.out.println("Enter a valid choice between 1-6");
			break;
		}
		
		
		
	}

	private static void showEmployees(List<Employee> empL) {
	Iterator<Employee> iterator = empL.iterator();
	while(iterator.hasNext()){
		System.out.println(iterator.next());
	}
	}

	private static void addNewEmployee(Employee employee) {
		try {
			employeeService.addNewEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}

	private static void deleteEmployee(Integer empid){
		try {
			employeeService.deleteEmployee(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
	
	}
	private static void updateEmployee(Employee employee) {
		
		try {
			
			employeeService.updateEmployee(employee);;
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
	
	}
private static Employee getEmployeeDetails(Integer empid) {
		
		try {
			return employeeService.getEmployeeDetails(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		return null;
	
	}
	
/*private static List<Employee> getAllEmployees() {
	
    List<Employee>employeeList;
	try {
		employeeList=employeeService.getAllEmployees();
		return employeeList ;
	} catch (EmployeeException e) {			
		e.printStackTrace();
	}
	return null;
}
*/
}
